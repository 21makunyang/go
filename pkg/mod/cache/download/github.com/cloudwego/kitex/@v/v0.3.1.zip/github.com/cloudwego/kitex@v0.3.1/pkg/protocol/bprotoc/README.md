# bprotoc

1. only support proto3 now.
2. any is not supported now.