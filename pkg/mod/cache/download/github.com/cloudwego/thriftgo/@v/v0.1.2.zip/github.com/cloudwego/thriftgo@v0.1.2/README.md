
thriftgo
========

thriftgo is an implementation of thrift compiler in go language.

