package attention

import "testing"

func TestAppendInt(t *testing.T) {
	AppendInt()
}
