package attention

import "testing"

func TestClosure(t *testing.T) {
	closure()
}


func TestClosure1(t *testing.T) {
	closure1()
}
