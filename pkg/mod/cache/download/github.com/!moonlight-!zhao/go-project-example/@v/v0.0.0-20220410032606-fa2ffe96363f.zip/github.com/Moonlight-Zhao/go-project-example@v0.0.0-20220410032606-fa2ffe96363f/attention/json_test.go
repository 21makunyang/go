package attention

import "testing"

func TestNumUnmarshal(t *testing.T){
	NumUnmarshal()
}

func TestNumDecode(t *testing.T){
	NumDecode()
}
