package attention

import "testing"

func TestLength(t *testing.T){
	length()
}

func TestLength1(t *testing.T){
	length1()
}